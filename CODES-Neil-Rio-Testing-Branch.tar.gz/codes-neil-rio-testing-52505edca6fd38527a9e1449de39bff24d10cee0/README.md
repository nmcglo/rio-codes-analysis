http://www.mcs.anl.gov/projects/codes/ 

CODES is a set of models and utilities to aid in building parallel discrete
event simulations, on top of the ROSS simulation framework
(https://github.com/carothersc/ROSS).

Documentation can be found in the doc subdirectory. Particularly,
doc/BUILD\_STEPS documents the build process and doc/GETTING\_STARTED documents
library features at a high level.
