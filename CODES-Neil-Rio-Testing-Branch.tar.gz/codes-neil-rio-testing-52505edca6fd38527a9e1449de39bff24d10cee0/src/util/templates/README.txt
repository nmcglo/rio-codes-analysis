These contain LP definition templates, with the hope that you can copy/paste
and substitute template with your LP's name. At the moment, they are integrated
into the build system to keep them from being out of date, but aren't actually
linked into any libraries

'make tests' will compile the dummy main program along with the templates
themselves. 
