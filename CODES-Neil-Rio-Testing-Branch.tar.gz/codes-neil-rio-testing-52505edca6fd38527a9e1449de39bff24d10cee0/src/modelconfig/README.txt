The modelconfig code is based on the IOFSL server config tools
