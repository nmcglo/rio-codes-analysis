#!/bin/bash

tests/modelnet-p2p-bw --sync=1 -- tests/conf/modelnet-p2p-bw-loggp.conf
